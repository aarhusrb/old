require 'test/unit'
require 'backend'

class BackendTest < Test::Unit::TestCase
  def setup
    @backend = Backend.new 'Rubybrigade'
    @backend.clear!
  end
  
  def test_can_create_user
    @backend.create_user('olefriis', :name => 'Ole Østergaard', :telephone_number => '61 79 00 38')
    
    user = @backend.find_user 'olefriis'
    assert_equal 'olefriis', user['user_name']
    assert_equal 'Ole Østergaard', user['name']
    assert_equal '61 79 00 38', user['telephone_number']
  end
end