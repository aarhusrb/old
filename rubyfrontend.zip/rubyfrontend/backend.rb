require 'rubygems'
require 'cassandra'
include Cassandra::Constants

class Backend
  def initialize(keyspace, server='127.0.0.1:9160')
    @client = Cassandra.new(keyspace, server)
  end
  
  def clear!
    @client.clear_keyspace!
  end
  
  # En lille kommentar: Til mødet lavede jeg en id til brugerne. Til det brugte
  # jeg en lille, kryptisk hjælpemetode som gav UUID.new.to_i.to_s. Det gav slet
  # ingen mening, og det er heller ikke nødvendigt. Derfor fjernet...
  # Ved næste møde finder jeg nok ud af hvorfor hjælpemetoden var nødvendig...
  def create_user(user_name, attributes)
    @client.insert(:Users, user_name, {'user_name' => user_name, 'name' => attributes[:name], 'telephone_number' => attributes[:telephone_number]})
  end
  
  def find_user(user_name)
    @client.get(:Users, user_name)
  end
end